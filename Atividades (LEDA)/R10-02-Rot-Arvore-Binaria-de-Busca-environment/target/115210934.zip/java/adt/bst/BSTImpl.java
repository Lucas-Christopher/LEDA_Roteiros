package adt.bst;

public class BSTImpl<T extends Comparable<T>> implements BST<T> {

	protected BSTNode<T> root;

	public BSTImpl() {
		root = new BSTNode.Builder().data(null).left(null).right(null).parent(null).build();
	}

	public BSTNode<T> getRoot() {
		return this.root;
	}

	@Override
	public boolean isEmpty() {
		return root.isEmpty();
	}

	@Override
	public int height() {
		return height(this.root);
	}

	private int height(BSTNode<T> node) {
		if (node.isEmpty())
			return -1;
		
		int leftHeight = height((BSTNode<T>) node.getLeft());
		int rigthHeight = height((BSTNode<T>) node.getRight());
		
		return 1 + Math.max(leftHeight, rigthHeight);
		
	}

	@Override
	public BSTNode<T> search(T element) {
		return search(this.root, element);
	}

	private BSTNode<T> search(BSTNode<T> node, T element) {
		if (node.isEmpty() || node.getData().equals(element))
			return node;

		if (node.getData().compareTo(element) > 0)
			return search((BSTNode<T>) node.getLeft(), element);
		else
			return search((BSTNode<T>) node.getRight(), element);

	}

	@Override
	public void insert(T element) {
		if (element == null)
			return;
		else
			insert(this.root, element);
	}

	private void insert(BSTNode<T> node, T element) {
		if (node.isEmpty()) {
			node.setData(element);
			node.setLeft(new BSTNode<T>());
			node.setRight(new BSTNode<T>());
			node.getLeft().setParent(node);
			node.getRight().setParent(node);
		} else {
			if (node.getData().compareTo(element) > 0)
				insert((BSTNode<T>) node.getLeft(), element);

			else
				insert((BSTNode<T>) node.getRight(), element);
		}
	}

	@Override
	public BSTNode<T> maximum() {
		BSTNode<T> aux = this.root;

		if (aux.isEmpty())
			return null;

		else {
			while (!aux.getRight().isEmpty())
				aux = (BSTNode<T>) aux.getRight();
		}
		return aux;
	}

	@Override
	public BSTNode<T> minimum() {
		BSTNode<T> aux = new BSTNode.Builder().data(this.root.getData()).left(this.root.getLeft())
				.right(this.root.getRight()).parent(this.root.getParent()).build();

		if (aux.isEmpty())
			return null;

		else {
			while (!aux.getLeft().isEmpty())
				aux = (BSTNode<T>) aux.getLeft();
		}
		return aux;
	}

	@Override
	public BSTNode<T> sucessor(T element) {

		BSTNode<T> node = search(element);

		if (node.isEmpty())
			return null;

		if (!node.getRight().isEmpty()) {
			BSTNode<T> aux = (BSTNode<T>) node.getRight();
			while (!aux.getLeft().isEmpty()) {
				aux = (BSTNode<T>) aux.getLeft();
			}
			return aux;
		}
		BSTNode<T> aux2 = node;
		while (aux2.getParent() != null && !aux2.getParent().isEmpty() && aux2.getParent().getRight() == aux2) {
			aux2 = (BSTNode<T>) aux2.getParent();
		}
		if (aux2.getParent() == null || aux2.getParent().isEmpty())
			return null;

		return (BSTNode<T>) aux2.getParent();

	}

	@Override
	public BSTNode<T> predecessor(T element) {

		BSTNode<T> node = search(element);

		if (node.isEmpty())
			return null;

		if (!node.getLeft().isEmpty()) {
			BSTNode<T> aux = (BSTNode<T>) node.getLeft();
			while (!aux.getRight().isEmpty()) {
				aux = (BSTNode<T>) aux.getRight();
			}
			return aux;
		}
		BSTNode<T> aux2 = node;
		while (aux2.getParent() != null && !aux2.getParent().isEmpty() && aux2.getParent().getLeft() == aux2) {
			aux2 = (BSTNode<T>) aux2.getParent();
		}
		if (aux2.getParent() == null || aux2.getParent().isEmpty())
			return null;

		return (BSTNode<T>) aux2.getParent();
	}

	@Override
	public void remove(T element) {
		if (this.isEmpty())
			return;

		remove(this.root, element);
	}

	private void remove(BSTNode<T> node, T element) {
		BSTNode<T> aux = search(element);

		if (node.isEmpty())
			return;

		if (aux.isEmpty())
			return;

		if (node.getData().equals(element)) {
			if (this.size() == 1)
				node.setData(null);
			else
				this.removeGradeTwo(node);
		}
		else {
			if (aux.isLeaf())
				removeLeaf(aux);

			else if (!aux.getLeft().isEmpty() && !aux.getRight().isEmpty())
				removeGradeTwo(aux);

			else
				removeGradeOne(aux);
		}
	}

	private void removeLeaf(BSTNode<T> node) {
		if (node.getParent().getRight().getData() == node.getData())
			node.getParent().setRight(new BSTNode<T>());

		else
			node.getParent().setLeft(new BSTNode<T>());
	}

	private void removeGradeOne(BSTNode<T> node) {
		BSTNode<T> aux = null;

		if (node.getLeft().isEmpty()) {
			aux = (BSTNode<T>) node.getRight();
		} else {
			aux = (BSTNode<T>) node.getLeft();
		}

		if (node.getParent().getRight().getData() == node.getData()) {
			aux.setParent(node.getParent());
			node.getParent().setRight(aux);
		} else {
			aux.setParent(node.getParent());
			node.getParent().setLeft(aux);
		}
	}

	private void removeGradeTwo(BSTNode<T> node) {
		BSTNode<T> aux = sucessor(node.getData());

		if (aux != null) {
			node.setData(aux.getData());

			if (aux.isLeaf())
				removeLeaf(aux);
			else
				removeGradeOne(aux);
		}
	}

	@Override
	public T[] preOrder() {
		T[] array = (T[]) new Comparable[this.size()];
		
		if (!this.isEmpty()) {
			int i = 0;
			preOrder(this.root, array, i);
		}
		return array;
	}

	private void preOrder(BSTNode<T> node, T[] array, int i) {

		if (!node.isEmpty()) {

			while (array[i] != null)
				i++;

			array[i] = node.getData();

			if (!node.getLeft().isEmpty())
				preOrder((BSTNode<T>) node.getLeft(), array, i);

			if (!node.getRight().isEmpty())
				preOrder((BSTNode<T>) node.getRight(), array, i);
		}
	}

	@Override
	public T[] order() {
		T[] array = (T[]) new Comparable[this.size()];
		
		if (!this.isEmpty()) {
			int i = 0;
			order(this.root, array, i);
		}
		return array;
	}

	private void order(BSTNode<T> node, T[] array, int i) {
		if (!node.isEmpty()) {

			if (!node.getLeft().isEmpty())
				order((BSTNode<T>) node.getLeft(), array, i);
			
			
			while (array[i] != null)
				i++;
			
			array[i] = node.getData();

			if (!node.getRight().isEmpty())
				order((BSTNode<T>) node.getRight(), array, i);
		}
	}

	@Override
	public T[] postOrder() {
		T[] array = (T[]) new Comparable[this.size()];
		
		if (!this.isEmpty()) {
			int i = 0;
			postOrder(this.root, array, i);
		}

		return array;
	}

	private void postOrder(BSTNode<T> node, T[] array, int i) {

		if (!node.isEmpty()) {

			if (!node.getLeft().isEmpty())
				preOrder((BSTNode<T>) node.getLeft(), array, i);
			
			if (!node.getRight().isEmpty())
				preOrder((BSTNode<T>) node.getRight(), array, i);
			
			while (array[i] != null)
				i++;
			
			array[i] = node.getData();
		}
	}

	/**
	 * This method is already implemented using recursion. You must understand
	 * how it work and use similar idea with the other methods.
	 */
	@Override
	public int size() {
		return size(this.root);
	}

	private int size(BSTNode<T> node) {
		int result = 0;
		// base case means doing nothing (return 0)
		if (!node.isEmpty()) { // indusctive case
			result = 1 + size((BSTNode<T>) node.getLeft()) + size((BSTNode<T>) node.getRight());
		}
		return result;
	}

}
