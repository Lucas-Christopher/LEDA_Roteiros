package adt.skipList;

public class SkipListImpl<T> implements SkipList<T> {

	protected SkipListNode<T> root;
	protected SkipListNode<T> NIL;

	protected int maxHeight;

	protected double PROBABILITY = 0.5;

	public SkipListImpl(int maxHeight) {
		this.maxHeight = maxHeight;
		root = new SkipListNode(Integer.MIN_VALUE, maxHeight, null);
		NIL = new SkipListNode(Integer.MAX_VALUE, maxHeight, null);
		connectRootToNil();
	}

	/**
	 * Faz a ligacao inicial entre os apontadores forward do ROOT e o NIL Caso
	 * esteja-se usando o level do ROOT igual ao maxLevel esse metodo deve
	 * conectar todos os forward. Senao o ROOT eh inicializado com level=1 e o
	 * metodo deve conectar apenas o forward[0].
	 */
	private void connectRootToNil() {
		for (int i = 0; i < maxHeight; i++) {
			root.forward[i] = NIL;
		}
	}
	
	@Override
	public void insert(int key, T newValue, int height) {
		if (height < 0 || newValue == null)
			return;

		SkipListNode[] update = new SkipListNode[this.maxHeight];
		SkipListNode<T> aux = this.root;

		// Descendo os niveis da lista para encontrar o lugar da insercao.
		// Pesquisa o local.
		for (int i = this.maxHeight - 1; i >= 0; i--) {
			while (aux.forward[i] != null && aux.forward[i].getKey() < key)
				aux = aux.forward[i];
			update[i] = aux; // Guarda o caminho.
		}
		aux = aux.forward[0];

		if (aux.getKey() == key)
			aux.setValue(newValue);
		else {
			if (height > this.maxHeight) {
				for (int i = this.maxHeight; i < height; i++)
					update[i] = this.root;

				this.maxHeight = height;
			}
			aux = new SkipListNode<T>(key, height, newValue);

			// Altera os ponteiros.
			for (int i = 0; i < height; i++) {
				aux.forward[i] = update[i].forward[i];
				update[i].forward[i] = aux;
			}
		}
	}

	@Override
	public void remove(int key) {
		SkipListNode<T>[] update = new SkipListNode[this.maxHeight];
		SkipListNode<T> aux = this.root;

		// Pesquisa o local.
		for (int i = this.maxHeight - 1; i >= 0; i--) {
			while (aux.forward[i] != null && aux.forward[i].getKey() < key)
				aux = aux.forward[i];
			update[i] = aux; // Guarda o caminho.
		}
		aux = aux.forward[0];

		if (aux.getKey() == key) {
			// Ajeita os ponteiros.
			for (int i = 0; i < this.maxHeight; i++) {
				if (update[i].forward[i] != aux) break;
				update[i].forward[i] = aux.forward[i];
			}
		}
	}

	@Override
	public int height() {
		if (size() == 0) return 0;
		
		else {
			SkipListNode<T> aux = this.root.forward[0];
			
			int height = 0;
			
			while (!aux.equals(this.NIL)) {
				if (height < aux.height())
					height = aux.height();
				aux = aux.forward[0];
			}
			return height;
		}
	}

	@Override
	public SkipListNode<T> search(int key) {
		SkipListNode<T>[] update = new SkipListNode[this.maxHeight];
		SkipListNode<T> aux = this.root;

		// Pesquisa o local.
		for (int i = this.maxHeight - 1; i >= 0; i--) {
			while (aux.forward[i] != null && aux.forward[i].getKey() < key)
				aux = aux.forward[i];
			update[i] = aux; // Guarda o caminho.
		}
		aux = aux.forward[0];
		
		if (aux.getKey() == key) return aux;
		else return null;
	}

	@Override
	public int size() {
		int level = 0;
		int size = 0;
		
		SkipListNode<T> aux = this.root;

		while (aux.forward[level] != this.NIL) {
			aux = aux.forward[level];
			size++;
		}
		return size;
	}

	@Override
	public SkipListNode<T>[] toArray() {
		int size = this.size() + 2; // Incluindo nos sentinelas.
		
		SkipListNode<T>[] result = new SkipListNode[size];
		SkipListNode<T> aux = this.root;
		
		for (int i = 0; i < size; i++) {
			result[i] = aux;
			aux = aux.forward[0];
		}
		return result;
	}
}