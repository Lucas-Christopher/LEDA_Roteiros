package adt.hashtable.closed;

import java.util.LinkedList;
import util.*;

import adt.hashtable.hashfunction.HashFunction;
import adt.hashtable.hashfunction.HashFunctionClosedAddress;
import adt.hashtable.hashfunction.HashFunctionClosedAddressMethod;
import adt.hashtable.hashfunction.HashFunctionFactory;

public class HashtableClosedAddressImpl<T> extends AbstractHashtableClosedAddress<T> {

	/**
	 * A hash table with closed address works with a hash function with closed
	 * address. Such a function can follow one of these methods: DIVISION or
	 * MULTIPLICATION. In the DIVISION method, it is useful to change the size
	 * of the table to an integer that is prime. This can be achieved by
	 * producing such a prime number that is bigger and close to the desired
	 * size.
	 * 
	 * For doing that, you have auxiliary methods: Util.isPrime and
	 * getPrimeAbove as documented bellow.
	 * 
	 * The length of the internal table must be the immediate prime number
	 * greater than the given size. For example, if size=10 then the length must
	 * be 11. If size=20, the length must be 23. You must implement this idea in
	 * the auxiliary method getPrimeAbove(int size) and use it.
	 * 
	 * @param desiredSize
	 * @param method
	 */

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public HashtableClosedAddressImpl(int desiredSize, HashFunctionClosedAddressMethod method) {
		int realSize = desiredSize;

		if (method == HashFunctionClosedAddressMethod.DIVISION) {
			realSize = this.getPrimeAbove(desiredSize); // real size must the
			// the immediate prime
			// above
		}
		initiateInternalTable(realSize);
		HashFunction function = HashFunctionFactory.createHashFunction(method, realSize);
		this.hashFunction = function;
	}

	// AUXILIARY
	/**
	 * It returns the prime number that is closest (and greater) to the given
	 * number. You can use the method Util.isPrime to check if a number is
	 * prime.
	 */
	int getPrimeAbove(int number) {
		int primeAbove = 0;

		if (number > 0) {
			int aux = 2;

			if (number > 2 && (number % 2 == 0))
				aux = 1;

			primeAbove = number + aux;

			// Se o numero for par, ele anda de um em um. Caso contrario, anda
			// de dois em dois.
			while (!Util.isPrime(primeAbove))
				primeAbove += aux;
		}
		return primeAbove;
	}

	// Retorna a posicao da linkedList na tabela.
	private LinkedList<T> objectOnPosition(T element) {
		return (LinkedList<T>) super.table[((HashFunctionClosedAddress<T>) super.hashFunction).hash(element)];
	}

	@Override
	public void insert(T element) {
		if (element == null)
			return;

		LinkedList<T> linkedList = this.objectOnPosition(element);

		// Se a lista da posicao nao existir...
		if (linkedList == null) {

			super.table[((HashFunctionClosedAddress<T>) super.hashFunction).hash(element)] = new LinkedList<T>();

			linkedList = this.objectOnPosition(element);
			linkedList.add(element);
			super.elements++;
		}
		// Caso contrario...
		else {
			linkedList.add(element);
			super.elements++;
			super.COLLISIONS++;
		}
	}

	@Override
	public void remove(T element) {
		if (element == null)
			return;

		LinkedList list = this.objectOnPosition(element);

		if ((list != null) && list.contains(element)) {
			list.remove();
			super.elements--;

			// Caso de remover e ainda tiver elementos na linkedList...
			if (!list.isEmpty())
				super.COLLISIONS--;
		}
	}

	@Override
	public T search(T element) {
		// if (element == null) return null;

		// LinkedList da posicao que o elemento estah.
		LinkedList list = this.objectOnPosition(element);

		if (list != null && list.contains(element))
			return element;
		else
			return null;
	}

	@Override
	public int indexOf(T element) {
		// LinkedList da posicao que o elemento estah.
		LinkedList list = this.objectOnPosition(element);

		if (list != null && list.contains(element))
			return ((HashFunctionClosedAddress<T>) hashFunction).hash(element);
		else
			return -1;
	}

}
