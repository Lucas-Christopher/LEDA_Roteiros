package adt.linkedList;

public class RecursiveDoubleLinkedListImpl<T> extends RecursiveSingleLinkedListImpl<T> implements DoubleLinkedList<T> {

	protected RecursiveDoubleLinkedListImpl<T> previous;

	public RecursiveDoubleLinkedListImpl() {}

	public RecursiveDoubleLinkedListImpl(T data, RecursiveSingleLinkedListImpl<T> next,
			RecursiveDoubleLinkedListImpl<T> previous) {
		super(data, next);
		this.previous = previous;
	}

	@Override
	public void insertFirst(T element) {

		if (element == null)
			return;

		if (this.isEmpty()) {
			super.data = (element);
			super.next = new RecursiveDoubleLinkedListImpl<>();
			return;
		}

		RecursiveDoubleLinkedListImpl<T> newHeadNode = new RecursiveDoubleLinkedListImpl<T>(this.data, super.next,
				this.previous);

		super.next = newHeadNode;
		this.setData(element);
	}

	@Override
	public void removeFirst() {

		if (this.isEmpty())
			return;

		if (super.next.getNext() == null)
			super.next = null;

		this.setData(super.next.getData());
		this.setNext(super.next.getNext());
	}

	@Override
	public void removeLast() {

		if (this.isEmpty())
			return;

		if (super.next.getNext().isEmpty())
			this.setNext(new RecursiveDoubleLinkedListImpl<>());

		else
			((RecursiveDoubleLinkedListImpl<T>) super.next).removeLast();

	}

	// Insert Last.
	@Override
	public void insert(T element) {

		if (element == null)
			return;

		if (isEmpty()) {
			super.data = element;
			super.setNext(new RecursiveDoubleLinkedListImpl<>());

			if (this.previous == null)
				this.previous = new RecursiveDoubleLinkedListImpl<>();
		} else
			super.next.insert(element);
	}

	public RecursiveDoubleLinkedListImpl<T> getPrevious() {
		return previous;
	}

	public void setPrevious(RecursiveDoubleLinkedListImpl<T> previous) {
		this.previous = previous;
	}

	public T getLast() {

		RecursiveDoubleLinkedListImpl<T> node = (RecursiveDoubleLinkedListImpl<T>) super.next;
		while (node.next != null)
			node = (RecursiveDoubleLinkedListImpl<T>) node.next;

		return node.getData();
	}

}
