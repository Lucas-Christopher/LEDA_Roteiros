package adt.avltree;

import adt.bst.BSTImpl;
import adt.bst.BSTNode;
import adt.bt.Util;

/**
 * 
 * Performs consistency validations within a AVL Tree instance
 * 
 * @author Claudio Campelo
 *
 * @param <T>
 */
public class AVLTreeImpl<T extends Comparable<T>> extends BSTImpl<T> implements AVLTree<T> {

	// TODO Do not forget: you must override the methods insert and remove
	// conveniently.

	@Override
	public void insert(T element) {
		if (element == null)
			return;

		insert(super.root, element);
	}

	private void insert(BSTNode<T> node, T element) {
		if (node.isEmpty()) {
			node.setData(element);
			node.setLeft(new BSTNode<T>());
			node.setRight(new BSTNode<T>());
			node.getLeft().setParent(node);
			node.getRight().setParent(node);
		} else {
			if (node.getData().compareTo(element) > 0)
				insert((BSTNode<T>) node.getLeft(), element);
			else
				insert((BSTNode<T>) node.getRight(), element);
		}
	}

	@Override
	public void remove(T element) {
		BSTNode<T> foundNode = super.search(element);

		removeRecursive(foundNode);
	}

	private void removeRecursive(BSTNode<T> node) {
		if (!node.isEmpty()) {
			// FOLHA
			if (node.isLeaf()) {
				this.removeLeaf(node);
				rebalanceUp(node);
			}

			// UM FILHO
			else if (node.getLeft().isEmpty() || node.getRight().isEmpty()) {
				// SE NAO EH RAIZ...
				if (node.getParent() != null) {

					// SE NODE EH FILHO DA ESQUERDA...
					if (node.getParent().getLeft().equals(node)) {
						// SE TEM FILHO NA ESQUERDA...
						if (!node.getLeft().isEmpty()) {
							node.getParent().setLeft(node.getLeft());
							node.getLeft().setParent(node.getParent());
						}
						// SE TEM FILHO NA DIREITA...
						else {
							node.getParent().setRight(node.getRight());
							node.getRight().setParent(node.getParent());
						}
					}
					// SE NODE EH FILHO DA DIREITA...
					else {
						// SE TEM FILHO NA ESQUERDA...
						if (!node.getLeft().isEmpty()) {
							node.getParent().setRight(node.getLeft());
							node.getLeft().setParent(node.getParent());
						}
						// SE TEM FILHO NA DIREITA...
						else {
							node.getParent().setRight(node.getRight());
							node.getRight().setParent(node.getParent());
						}
					}
				} // SE O NOH EH RAIZ...
				else {
					this.removeRoot(node);
				}
				rebalanceUp(node);
			}

			// DOIS FILHOS
			else {
				T suc = super.sucessor(node.getData()).getData();
				this.remove(suc);
				node.setData(suc);
			}
		}
	}

	protected void removeRoot(BSTNode<T> node) {
		if (node.getLeft().isEmpty())
			this.root = (BSTNode<T>) node.getLeft();
		else
			this.root = (BSTNode<T>) node.getRight();

		this.root.setParent(null);
	}

	protected void removeLeaf(BSTNode<T> node) {
		node.setData(null);
	}

	// AUXILIARY
	protected int calculateBalance(BSTNode<T> node) {
		if (node == null)
			return -1;

		if (!node.isEmpty()) {
			return height((BSTNode<T>) node.getLeft()) - height((BSTNode<T>) node.getRight());
		}
		return 0;
	}

	// AUXILIARY
	protected void rebalance(BSTNode<T> node) {
		if (node == null)
			return;
		if (node.isEmpty())
			return;

		int balance = this.calculateBalance(node);

		// Pendendo pra esquerda.
		if (balance > 1) {
			// Se o filho ta pendendo pra direita...
			if (this.calculateBalance((BSTNode<T>) node.getLeft()) <= -1) {
				// Rotacao dupla a esquerda.
				Util.leftRotation((BSTNode<T>) node.getLeft());
				Util.rightRotation(node);
			} else {
				Util.rightRotation(node);
			}
		}
		// Pendendo pra direita.
		else {
			// Se o filho ta pendendo pra esquerda...
			if (this.calculateBalance((BSTNode<T>) node.getRight()) >= 1) {
				// Rotacao dupla a direita.
				Util.rightRotation((BSTNode<T>) node.getRight());
				Util.leftRotation(node);
			} else {
				Util.leftRotation(node);
			}
		}
	}

	// AUXILIARY
	protected void rebalanceUp(BSTNode<T> node) {
		BSTNode<T> parent = (BSTNode<T>) node.getParent();

		while (parent != null && !parent.isEmpty()) {
			rebalance(parent);
			parent = (BSTNode<T>) parent.getParent();
		}
	}
}
